# TripSplit location stamps — expanded collection 02

Eighteen original vector stamps across eight countries. The expanded catalog adds twelve locations verified in the current codebase. The original six-stamp board remains available with a proposed collection screen and the existing 128-point profile rail treatment. Dates and collection counts are illustrative. This is a design proposal; the SwiftUI app has not been changed.

## Open in Figma

Drag `location-stamps-expanded.svg` into a Figma Design file for the complete 18-stamp catalog. `location-stamps-mockup.svg` retains the original screen-context study. Each stamp is also supplied as a separate SVG for reuse. Shapes and text are editable SVG elements, not a flattened screenshot. The SVG import has not been verified in Figma because its editing tools were unavailable in this session. Text uses Arial for portable mockup rendering; production UI should continue using the app's selected font and Dynamic Type. These files are not a native Figma component library with auto-layout or bound variables.

Open `index.html` for a browsable collection: filter by country, click a stamp for its detail, and download individual SVGs. `location-stamps-expanded.png` is the full collection preview; `location-stamps-mockup.png` shows the original screen-context study.

## Design decisions

- One ink per place, using existing app colors: pine #2A5F45, indigo #27356B, oxblood #9E3324.
- Round park/city seals and chamfered station seals share line weights, artwork proportions, and date placement.
- Original landmark silhouettes replace generic category icons. No official park-service or railway logos are used.
- Place name and date remain readable text outside the art at small sizes. Treat miniature decorative lettering as artwork, with a single combined accessibility label.
- Preserve the existing Add and Edit visited-place flow. The expanded collection screen is a proposed design, not an implemented destination.
- Only display dates when the app has a known visit date. For undated places, omit the date strip and external date caption; do not invent a visit date.
- Keep the user's full place name in the accessible label and detail view; allow two lines below the stamp for long names.
- At 128 points, prioritize the primary silhouette and place name. Subtle ink wear can be explored for large share-card artwork; keep compact UI clean.
- Use the app's existing adaptive ink variants for a future dark-mode implementation. This mockup illustrates light mode only.

## Inspiration

- National Park Service passport cancellation stamps: https://www.nps.gov/thingstodo/get-a-passport-stamp.htm
- JR East station stamp collection overview: https://media.jreast.co.jp/articles/4714

The proposal combines dated park-seal framing with place-specific station-stamp illustrations. Artwork is an original interpretation, not a reproduction of official stamps.

## Added locations and code references

| Location | New artwork | Existing source |
| --- | --- | --- |
| New York | Statue of Liberty | Tripsplit/PlaceStampArtwork.swift, PlaceLandmark.liberty |
| Chicago | Willis Tower | Tripsplit/PlaceStampArtwork.swift, PlaceLandmark.willisTower |
| Miami | South Beach lifeguard stand | Tripsplit/PlaceStampArtwork.swift, PlaceLandmark.lifeguardStand |
| Seattle | Space Needle | Tripsplit/PlaceStampArtwork.swift, PlaceLandmark.spaceNeedle |
| Honolulu | Diamond Head | Tripsplit/PlaceStampArtwork.swift, PlaceLandmark.diamondHead |
| Paris | Eiffel Tower | Tripsplit/ExploreModels.swift, paris destination |
| London | Elizabeth Tower | Tripsplit/ExploreModels.swift, london destination |
| Rome | Colosseum | Tripsplit/ExploreModels.swift, rome destination |
| Osaka | Osaka Castle | Tripsplit/ExploreModels.swift, osaka destination |
| Seoul | Gyeongbokgung | Tripsplit/ExploreModels.swift, seoul destination |
| Singapore | Supertree Grove | Tripsplit/ExploreModels.swift, singapore destination |
| Sydney | Opera House | Tripsplit/ExploreModels.swift, sydney destination |

The first six concepts (Yosemite, Kyoto, Tokyo, Lake Tahoe, San Francisco, Nara) are retained. This is an expanded selection, not exhaustive coverage of every destination or location alias in the app.
